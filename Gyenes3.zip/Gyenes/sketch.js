let mx=60;
let my=60;
let px=60;
let py=60;

let z=200;
let x=50;
let c= 150;

let eSize=3;
let eLoc=15;



function setup() {
  createCanvas(400, 400);
  colorMode(RGB,255,255,255,1);
  frameRate(10)
  angleMode(RADIANS);
}

function draw() {
  background(150);
  stroke(0,0,0,1);
  line(mouseX,mouseY,pmouseX,pmouseY);
  print(pmouseX+'->'+ mouseX);
  
  line(mouseX,350,mouseX,400);
  line(375,mouseY,400,mouseY);
  
  if (mouseY=== pmouseY && mouseX=== pmouseX){
    fill(0,222,222,1);
    stroke(6,50,46,20);
    ellipse(eLoc,eLoc,eSize,eSize);
    ellipse(eLoc*2,eLoc*2,pow(eSize,2),pow(eSize,2));
    ellipse(eLoc*4,eLoc*4,pow(eSize,3),pow(eSize,3));
    ellipse(eLoc*8,eLoc*8,pow(eSize,4),pow(eSize,4));
    ellipse(eLoc*16,eLoc*16,pow(eSize,5),pow(eSize,5));
    fill(80,100,255,1);
    ellipse(z,c,z,x+c,radians(180),radians(275));
  }
  print(pmouseY+'->'+mouseY);
    
  fill(225,225,0);
  rect(c,z,x,c+z);
  rect(z,c+x,z,x+x);
  fill(80,60,30,1);
  arc(z,c,z,x+c,-270,radians(-90));

  
  let x1=mouseX;
  let y1=350;
  let x2 =sqrt(x1);
  let y2=350;

  stroke(255,255,255,1);
  line(0,y1,width,y1);
  rect(x1,y1,eSize,eSize);
  noStroke();
  fill(0);
  let spacing=20;
  text('x='+x1,0,y1+spacing);

}
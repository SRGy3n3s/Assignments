function setup() {
  createCanvas(400, 400);
   background(0);
  angleMode(DEGREES);
}

function draw() {
  colorMode(RGB,255,255,255,1);
  fill(80,80,81,1)
    stroke(255)
  beginShape();
  vertex(50,50);
  vertex(350,50);
  vertex(350,350);
  vertex(50,350);
  beginContour();
  vertex(100,100);
  vertex(100,300);
  vertex(300,300);
  vertex(300,100);
  endContour();
  endShape();
  
  
  
fill(200,100,50,1);
  stroke(0);
  
  triangle(0,35,18,-20,46,35);
  triangle(30,75,58,20,86,75);
  triangle(70,115,98,60,126,115);
  triangle(110,155,138,100,166,155);
  triangle(150,195,178,140,206,195);
  triangle(190,235,218,180,246,235);
  triangle(230,275,258,220,286,275);
  triangle(270,315,298,260,326,315);
  triangle(310,355,338,300,366,355);
  triangle(350,395,378,340,406,395);

    fill(0);
  stroke(100,100,50,1);
   triangle(10,55,38,0,66,55);
  triangle(50,95,78,40,106,95);
   triangle(90,135,118,80,146,135);
  triangle(130,175,158,120,186,175);
  triangle(170,215,198,160,226,215);
  triangle(210,255,238,200,266,255);
  triangle(250,295,278,240,306,295);
  triangle(290,335,318,280,346,335);
  triangle(330,375,358,320,386,375);
   triangle(370,415,398,360,426,415);
  //OrangeTriangles//
  
  fill(70,90,200,1);
  stroke(255);
  arc(325,320,200,240,-100,-180);
  
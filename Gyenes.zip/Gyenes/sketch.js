function setup() {
	createCanvas(128,128);
}

function draw() {
  background(0);
  noFill();
  stroke(118)
  strokeCap(PROJECT);
  strokeJoin(BEVEL);
  strokeWeight(6.0);
//Stroke and no fill
 ellipse(10,10,30,30)
  
 
  rect(0,60,10,70);
  rect(10,80,15,50);
  rect(20,70,30,70);
  rect(50,50,10,80);
  rect(60,60,10,80);
rect(70,50,20,80);
rect(90,90,10,40);
  rect(100,70,15,60)
  rect(110,60,20,80);
//Buildings


point(40,10);
  point(45,30)
  point(65,30)
  point(75,15)
  point(85,15)
  point(100,10)
  point(120,20)
//Mock Big Dipper concellation
}
